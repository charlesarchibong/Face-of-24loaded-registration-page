<!DOCTYPE html>
<html lang="zxx">

<head>
    <title>Face Of 24loaded 2019</title>
    <!-- Meta tag Keywords -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8" />
    <meta name="keywords"
        content="faceof24loade, 24loaded.com, peagent, beauty" />
    <!-- //Meta tag Keywords -->
    <link rel="stylesheet" href="css/style.css" type="text/css" media="all" /><!-- Style-CSS -->
    <link href="css/font-awesome.css" rel="stylesheet"><!-- font-awesome-icons -->
    <style type="text/css">
    	.list-margin{
    		margin-bottom: 15px;
    	}
    </style>
</head>
<body>
    <section class="signin-form">
        <div class="overlay">
            <div class="wrapper">
                <div class="logo text-center top-bottom-gap">
                    <a class="brand-logo" href="index.php">Face Of 24LOADED 2019</a>
                </div>
                <div class="form34">
                	
                 <h3 class="text-center" style="margin-bottom: 15px;"> Guidelines For Face Of 24loaded</h3>

<ol>
<li class="list-margin">It's an online contest For only females, Registration fee is 2000 naira.</li>

<li class="list-margin"> You will be requested to submit a Well Captured photo of yourself to our Email 24loadedentertainmen­t@gmail.com, after registration.</li>

<li class="list-margin">The photo will be uploaded to our Facebook page (De bloodlines) for the contest to begin.</li>

<li class="list-margin">The winner of the contest wins 20,000 naira, her face on 24loaded cover art for a period of 1 year and a free ticket to funfest calabar.</li>

<li class="list-margin">Contest starts from 5th of November to 31st November.</li>

<li class="list-margin">The picture with the highest likes and comment becomes the winner.</li>

<li class="list-margin">The winner may be asked to return the following year to the platform.</li>
</ol>

<b >Note!</b> You are to boost publicity to your friends to enable you win the contest.</b>

All payment for Registration will be sent to the following account details:<br>
 <b>Account Number</b> - 0469424071<br>
<b>Account Name:</b> Garba Success Mustapha<br>
<b>Bank:</b> GT Bank<br><br>

If the winner is within calabar area, we will request a sit out where the cash will be given. If the winner is outside calabar we will request for your account details and make payment Asap.

Face Of 24loaded was brought to you by Emperors bloodline and powered by 24loaded Entertainment(24loaded.com)  
<a href="register">Click here to register</a>
                </div>
            </div>
            <!-- copyright -->
		<div class="copyright text-center">
                <p>© 2019 FaceOf24loaded . All rights reserved | Design by <a href="http://24loaded.com" target="_blank">24loaded Ent.</a></p>
            </div>
            <!-- //copyright --> 
        </div>
    </section>
</body>

</html>
