<?php
include_once ("dbconn.php");
    if(isset($_POST['name'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $location = $_POST['location'];
    $facebook_id = $_POST['fbhandle'];
    $age = $_POST['age'];
                                        
   $sql = "INSERT INTO contestants (name, email, phone, location, facebook_id, age) VALUES (?, ?, ?, ?, ?, ?)";
   $mysqli = new mysqli("localhost", "root", "", "faceof24loaded");
   $stmt = $mysqli->prepare($sql);
   $stmt->bind_param('ssssss', $name, $email, $phone, $location, $facebook_id, $age);
   if($stmt->execute())
   {
   	$mysqli->close();
   	 echo("DONE");
   } else{

   	$mysqli->close();
   	echo("error");
   }
   }               
   
?>
