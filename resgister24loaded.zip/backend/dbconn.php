<?php
function dbConfig(){
//////////Establishing Database connection

	$mysqli = new mysqli("localhost", "root", "", "faceof24loaded");
	
	return 	$mysqli;
}
	
?>